<?php
        if (!session_id()) session_start();
        $db = mysqli_connect( 'localhost', 'root', '', 'registration' );
        if ( ! $db ) {
                die( "Connection failed: " . mysqli_connect_error() );

        }
?>